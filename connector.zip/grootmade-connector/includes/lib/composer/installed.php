<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '06eb97ab092d33cd659021d67390c4adc24b521f',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '06eb97ab092d33cd659021d67390c4adc24b521f',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
